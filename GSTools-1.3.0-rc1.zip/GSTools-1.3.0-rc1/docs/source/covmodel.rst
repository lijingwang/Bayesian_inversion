gstools.covmodel
================

.. automodule:: gstools.covmodel

.. raw:: latex

    \clearpage

.. toctree::
   :hidden:

   covmodel.plot.rst

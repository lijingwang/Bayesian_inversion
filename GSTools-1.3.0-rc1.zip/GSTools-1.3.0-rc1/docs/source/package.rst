===========
GSTools API
===========

.. automodule:: gstools

.. raw:: latex

    \clearpage

.. toctree::
   :hidden:

   covmodel.rst
   field.rst
   variogram.rst
   krige.rst
   random.rst
   tools.rst
   transform.rst

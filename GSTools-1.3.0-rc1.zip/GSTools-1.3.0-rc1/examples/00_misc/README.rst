Miscellaneous Tutorials
=======================

More examples which do not really fit into other categories. Some are not more
than a code snippet, while others are more complex and more than one part of
GSTools is involved.

Examples
--------

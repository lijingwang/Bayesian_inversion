# GSTools

GSTools is available on [GitHub](https://github.com/GeoStat-Framework/GSTools)
and was created by following people.


## Main Authors

- [Lennart Schüler](https://github.com/LSchueler), Email:  <lennart@geostat-framework.org>
- [Sebastian Müller](https://github.com/MuellerSeb), Email:  <sebastian@geostat-framework.org>


## Contributors (in order of contributions)

- Falk Heße, Email: <falk.hesse@ufz.de>
- Bane Sullivan, GitHub: [@banesullivan](https://github.com/banesullivan)
